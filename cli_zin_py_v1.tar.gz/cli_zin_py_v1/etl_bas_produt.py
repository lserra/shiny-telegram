#!/usr/bin/python
# -*- coding: utf-8 -*-


"""
Summary: CLI - database extract utility
Description: Move the data from STAGE AREA (RPL_) to DATA MART (BAS_).
"""

# ===================================================================================================================
# VERSION:
# ===================================================================================================================
# 1.0 - 01/04/2016 - Leonardo Macedo - Move the data from BAGAGGIO server source to TDVTEC server target
# 2.0 - 07/05/2016 - Laercio Serra - Formatting the file, add docstrings and news code blocks
# 3.0 - 14/06/2016 - Laercio Serra - Add new colunm and change the statement to move the data to target
# ===================================================================================================================

import config_file as cfg
import pymssql as db_cli
import MySQLdb as db_tdv
import log_function as log

# ===================================================================================================================
# PARAMETERS
# ===================================================================================================================
# Define the parameter of the database server (SOURCE and TARGET are the same)
pars_tgt = cfg.load_from_file_host_target()
host_db_to = pars_tgt[0][1]
port_db_to = pars_tgt[1][1]
user_db_to = pars_tgt[2][1]
pwd_db_to = pars_tgt[3][1]
db_to = pars_tgt[4][1]


# TODO: put the part1 into a class
# ===================================================================================================================
# Part 1 - Operations with the Databases
# ===================================================================================================================
def open_db(host_db_to, port_db_to, user_db_to, pwd_db_to, db_to):
    """
    Connecting to the database SOURCE/TARGET
    :param host_db_to:
    :param port_db_to:
    :param user_db_to:
    :param pwd_db_to:
    :param db_to:
    """
    try:
        # Database SOURCE/TARGET
        con_tdv = db_tdv.connect(host=host_db_to, port=int(port_db_to), user=user_db_to, passwd=pwd_db_to, db=db_to)

        return con_tdv
    except db_tdv.Error, tdv:
        errmsg = "Database connection failed. Error %d: %s" % (tdv.args[0], tdv.args[1])
        print errmsg
    except db_tdv.Warning:
        pass


def close_db(con_tdv):
    """
    Closing connection with the database SOURCE/TARGET.
    :param con_tdv:
    """
    con_tdv.close()


def commit_db(con_tdv):
    """
    Commit the transactions to the database TARGET
    :param con_tdv:
    """
    try:
        con_tdv.commit()
    except db_tdv.Error, tdv:
        errmsg = "Commit transaction failed. Error %d: %s" % (tdv.args[0], tdv.args[1])
        print errmsg
    except db_tdv.Warning:
        pass


def rollback_db(con_tdv):
    """
    Rollback the transactions to the database TARGET
    :param con_tdv:
    """
    try:
        con_tdv.rollback()
    except db_tdv.Error, tdv:
        errmsg = "Rollback transaction failed. Error %d: %s" % (tdv.args[0], tdv.args[1])
        print errmsg
    except db_tdv.Warning:
        pass


# ===================================================================================================================
# Part 2 - ETL Tasks Operations
# a -> Extract the data from the RPL_ table source
# b -> Delete all rows in the target table before to load the data
# c -> Load the data to the BAS_ target table
# ===================================================================================================================
def etl_from_to_bas(source, target):
    """
    Connection with the table source to extract and move the data to the table target
    :param source:
    :param target:
    """
    status = 'OK'

    # Registering in the log
    log.grava_log_interface('Carga ' + target, 'Interface - inicio')

    # Opening the connections
    con_tdv = open_db(host_db_to, port_db_to, user_db_to, pwd_db_to, db_to)
    # Opening the cursors
    cur_cli = con_tdv.cursor()
    cur_tdv = con_tdv.cursor()

    # Registering in the log
    log.grava_log_interface('Carga ' + target, 'Consultando o banco do cliente - inicio')

    # a -> Building the statement to extract the data from table source
    res_cli = []
    sql_cli = 'SELECT * FROM ' + source
    try:
        cur_cli.execute(sql_cli)
        res_cli = cur_cli.fetchall()
        # Registering in the log
        log.grava_log_interface('Carga ' + target, 'Qtde. de linhas encontradas: ' + str(cur_cli.rowcount))
    except db_cli.Error, cli:
        # Registering in the log
        log.grava_log_interface('Carga ' + target, 'Consultando o banco do cliente - Erro')
        errmsg = "ETL data source failed. Error %d: %s" % (cli.args[0], cli.args[1])
        status = 'NOK'
    except db_cli.Warning:
        pass

    # Registering in the log
    log.grava_log_interface('Carga ' + target, 'Apagando os dados da tabela - inicio')

    # b -> Build the statement to delete all rows in the target table before of the loading the data
    # Delete all rows if exists rows in the table
    sql_tdv = 'SELECT COUNT(*) FROM %s' % target
    cur_tdv.execute(sql_tdv)
    rows_tdv = cur_tdv.fetchone()
    if rows_tdv[0] > 0:
        del_tdv = 'DELETE FROM ' + target
        # Deleting the data in the table target
        try:
            cur_tdv.execute(del_tdv)
            commit_db(con_tdv)
        except db_tdv.Error, tdv:
            rollback_db(con_tdv)
            # Registering the log
            log.grava_log_interface('Carga ' + target, 'Apagando os dados da tabela - Erro')
            errmsg = "ETL data target failed. Error %d: %s" % (tdv.args[0], tdv.args[1])
            status = 'NOK'
        except db_tdv.Warning:
            pass

    # Registering the log
    log.grava_log_interface('Carga ' + target, 'Gravando os dados na TDV - inicio')

    # c -> Build the statement to move the data to the table target
    ins_tdv = 'INSERT INTO ' + target + ' VALUES (%s, %s, %s, %s, %s)'

    # Moving the data to the table target
    try:
        for each_row in res_cli:
            cur_tdv.execute(ins_tdv, each_row)
            commit_db(con_tdv)
            # cur_tdv.executemany(ins_tdv, res_cli)
            # commit_db(con_cli, con_tdv)
    except db_tdv.Error, tdv:
        rollback_db(con_tdv)
        # Registering the log
        log.grava_log_interface('Carga ' + target, 'Gravando os dados na TDV - Erro')
        errmsg = "ETL data target failed. Error %d: %s" % (tdv.args[0], tdv.args[1])
        status = 'NOK'
    except db_tdv.Warning:
        pass
    # TODO: verificar se a qtde de linhas do target é igual ao source
    # Registering the log
    log.grava_log_interface('Carga ' + target, 'Fechando as conexoes com os bancos')

    # Registering the log
    log.grava_log_interface('Carga ' + target, 'Interface - termino')

    close_db(con_tdv)

    if status == 'OK':
        return 'OK', 'Carga executada com sucesso!'
    else:
        return 'NOK', errmsg


if __name__ == '__main__':
    source = 'RPL_PRODUTOS'
    target = 'BAS_PRODUTO'
    etl_from_to_bas(source, target)
