#!/usr/bin/python
# -*- coding: utf-8 -*-


"""
Summary: CLI - database extract utility
Description: Registering all the activities in the database of the TDVTEC
"""

# ===================================================================================================================
# VERSION:
# ===================================================================================================================
# 1.0 - 01/04/2016 - Leonardo Macedo - Registering all the activities
# 2.0 - 07/05/2016 - Laercio Serra - Formatting the file, add docstrings and news code blocks
# ===================================================================================================================

import config_file as cfg
import MySQLdb as db_tdv
import datetime as dt

# ===================================================================================================================
# PARAMETERS
# ===================================================================================================================
# Define the parameter of the database server TARGET
pars_tgt = cfg.load_from_file_host_target()
host_db_to = pars_tgt[0][1]
port_db_to = pars_tgt[1][1]
user_db_to = pars_tgt[2][1]
pwd_db_to = pars_tgt[3][1]
db_to = pars_tgt[4][1]


# TODO: fazer tratamento de exceções -> e se o bd estiver indisponível neste momento?
# ===================================================================================================================
# Part 1 - Registering all the activities in the database of the TDVTEC
# ===================================================================================================================
def grava_log_interface(nome_interface, acao):
    """
    Register the actions in the database
    :param nome_interface:
    :param acao:
    :return:
    """
    con_tdv_log = db_tdv.connect(host=host_db_to, port=int(port_db_to), user=user_db_to, passwd=pwd_db_to, db=db_to)
    cur_tdv_log = con_tdv_log.cursor()
    parametros = [nome_interface, acao]
    cur_tdv_log.execute('INSERT INTO CTRL_INTERFACES_EXECUTADAS(NOME_INTERFACE, ACAO, HORA_INICIO) '
                        'VALUES (%s, %s, NOW());', parametros)
    con_tdv_log.commit()
    con_tdv_log.close()


def data_parametro(data, dias):
    """
    Realize the treatment/transformation of a data type to date format
    :param data:
    :param dias:
    :return:
    """
    if data is None:
        data = dt.date(1970, 01, 01)
    data_interface = data - dt.timedelta(days=dias)

    ano = str(data_interface.year)
    mes = "00" + str(data_interface.month)
    dia = "00" + str(data_interface.day)

    data_ret_str = ano + mes[len(mes) - 2:len(mes)] + dia[len(dia) - 2:len(dia)]

    return data_ret_str, data_interface
