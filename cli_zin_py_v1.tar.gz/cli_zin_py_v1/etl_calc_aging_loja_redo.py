#!/usr/bin/python
# -*- coding: utf-8 -*-


"""
Summary: CLI - database extract utility
Description: O cálculo do aging consiste em determinar para cada peça armazenada hoje a quanto tempo ela está
armazenada. Para isso precisamos para cada sku do estoque em cada loja da empresa varrer todos as entradas, da
mais recente para a mais antiga, e identificar a data da entrada. Armazenamos a data da entrada e a quantidade
de peças, pois desta forma conseguimos mostrar a informação do Aging em diversos níveis e formas distintas de
agregação.
"""

# ===================================================================================================================
# VERSION:
# ===================================================================================================================
# 1.0 - 07/05/2016 - Laercio Serra - Coding the first version
# 2.0 - 20/05/2016 - Changes in the logical of the calc aging
# 3.0 - 23/05/2016 - Changes to do a reprocessment
# ===================================================================================================================

import config_file as cfg
import MySQLdb as db_tdv
import log_function as log

# ===================================================================================================================
# PARAMETERS
# ===================================================================================================================
# Define the parameter of the database server (SOURCE and TARGET are the same)
pars_tgt = cfg.load_from_file_host_target()
host_db_to = pars_tgt[0][1]
port_db_to = pars_tgt[1][1]
user_db_to = pars_tgt[2][1]
pwd_db_to = pars_tgt[3][1]
db_to = pars_tgt[4][1]


# ===================================================================================================================
# Part 1 - Operations with the Databases
# ===================================================================================================================
def open_db(host_db_to, port_db_to, user_db_to, pwd_db_to, db_to):
    """
    Connecting to the database SOURCE/TARGET
    :param host_db_to:
    :param port_db_to:
    :param user_db_to:
    :param pwd_db_to:
    :param db_to:
    """
    try:
        # Database SOURCE/TARGET
        con_tdv = db_tdv.connect(host=host_db_to, port=int(port_db_to), user=user_db_to, passwd=pwd_db_to, db=db_to)

        return con_tdv
    except db_tdv.Error, tdv:
        errmsg = "Database connection failed. Error %d: %s" % (tdv.args[0], tdv.args[1])
        print errmsg
    except db_tdv.Warning:
        pass


def close_db(con_tdv):
    """
    Closing connection with the database SOURCE/TARGET.
    :param con_tdv:
    """
    con_tdv.close()


def commit_db(con_tdv):
    """
    Commit the transactions to the database TARGET
    :param con_tdv:
    """
    try:
        con_tdv.commit()
    except db_tdv.Error, tdv:
        errmsg = "Commit transaction failed. Error %d: %s" % (tdv.args[0], tdv.args[1])
        print errmsg
    except db_tdv.Warning:
        pass


def rollback_db(con_tdv):
    """
    Rollback the transactions to the database TARGET
    :param con_tdv:
    """
    try:
        con_tdv.rollback()
    except db_tdv.Error, tdv:
        errmsg = "Rollback transaction failed. Error %d: %s" % (tdv.args[0], tdv.args[1])
        print errmsg
    except db_tdv.Warning:
        pass


# ===================================================================================================================
# Part 2 - ETL Calculate Aging
# Abrir um cursor de estoque com todos os SKUs com estoque positivo e ordenar por LOCAL e SKU. Apenas para
# facilitar caso o processamento seja interrompido. Para cada linha do cursor de estoque pegar o próximo SKU
# e armazenar o estoque atual em uma variável de controle.
# Abrir um cursor consolidado de movimentações, percorrer o cursor. Para cada linha do cursor de movimentação
# verificar se o saldo de estoque na variável de controle é maior que a quantidade recebida.
# Se "sim" gravar na tabela resultado e reduzir a variável de controle da quantidade de estoque da quantidade
# recebida. Se "não" gravar na tabela resultado, neste caso grava na tabela resultado o valor da variável de
# controle do estoque e não o valor da tabela de movimentação.
# Gravar a transação (efetuar o commit) e pular para o próximo produto do local.
# ===================================================================================================================
def etl_dat_aging_loja():
    """
    Calculate the aging of products and save the results into table DAT_AGING
    """
    status = 'OK'

    # Registering in the log
    log.grava_log_interface('Calculating AGING', 'Interface - inicio')

    # Opening the connections
    con_tdv = open_db(host_db_to, port_db_to, user_db_to, pwd_db_to, db_to)
    # Opening the cursors
    cur_est = con_tdv.cursor()  # stock cursor
    cur_mov = con_tdv.cursor()  # movement cursor (consolidated)
    cur_tdv = con_tdv.cursor()  # count, select, delete, insert and update rows

    # Registering in the log
    log.grava_log_interface('Calculating AGING', 'Consultando o banco do cliente - inicio')

    # Building the statement to populate the stock cursor
    sql_est = 'SELECT E.COD_LOCAL, E.COD_SKU, E.QTD_ESTOQUE FROM BAS_ESTOQUE E WHERE E.COD_SKU NOT IN ' \
              '(SELECT DISTINCT A.COD_SKU FROM DAT_AGING A ' \
              'ORDER BY A.COD_LOCAL, A.COD_SKU ) AND E.COD_LOCAL <> \'NI\';'
    try:
        cur_est.execute(sql_est)
        # Registering in the log
        log.grava_log_interface('Calculating AGING', 'Qtde. de linhas encontradas: ' + str(cur_est.rowcount))
    except db_tdv.Error, tdv:
        # Registering in the log
        log.grava_log_interface('Calculating AGING', 'Consultando o banco do cliente - Erro')
        errmsg = "ETL data source failed. Error %d: %s" % (tdv.args[0], tdv.args[1])
        status = 'NOK'
    except db_tdv.Warning:
        pass

    # Registering in the log
    # log.grava_log_interface('Calculating AGING', 'Apagando os dados da tabela - inicio')

    # Build the statement to delete all rows in the target table before of the loading the data
    # Delete all rows if exists rows in the table
    # sql_dat = 'SELECT COUNT(*) FROM DAT_AGING'
    # cur_tdv.execute(sql_dat)
    # rows_tdv = cur_tdv.fetchone()
    # if rows_tdv[0] > 0:
    #     del_tdv = 'DELETE FROM DAT_AGING'
    #     # Deleting the data in the table target
    #     try:
    #         cur_tdv.execute(del_tdv)
    #         commit_db(con_tdv)
    #     except db_tdv.Error, tdv:
    #         rollback_db(con_tdv)
    #         # Registering the log
    #         log.grava_log_interface('Calculating AGING', 'Apagando os dados da tabela - Erro')
    #         errmsg = "ETL data target failed. Error %d: %s" % (tdv.args[0], tdv.args[1])
    #         status = 'NOK'
    #     except db_tdv.Warning:
    #         pass

    # Registering the log
    log.grava_log_interface('Calculating AGING', 'Gravando os dados na TDV - inicio')

    # Calculating the aging and salving the data to the table target
    try:
        for each_est in cur_est:
            qtd_sku_est = each_est[2]
            # c -> Build the statement to populate the consolidated cursor
            sql_mov = 'SELECT COD_LOCAL, COD_SKU, QTD_RECEBIDA, TIPO_MOVIMENTO, DATA_MOVIMENTO ' \
                      'FROM AGR_MOVIMENTACAO ' \
                      'WHERE COD_LOCAL = ' + each_est[0] + \
                      ' AND TRIM(COD_SKU) = ' + str.strip(each_est[1]) + \
                      ' ORDER BY COD_LOCAL, COD_SKU, DATA_MOVIMENTO DESC;'
            cur_mov.execute(sql_mov)

            if cur_mov.rowcount == 0:
                pass
            else:
                dat_aging = []
                for each_sku in cur_mov:
                    # Para cada linha do cursor de movimentação verificar a
                    # a qtde movimentada e comparar com a qtde no estoque
                    qtd_sku_mov = each_sku[2]
                    if qtd_sku_est >= qtd_sku_mov:
                        qtd_sku_est = qtd_sku_est - qtd_sku_mov
                    elif qtd_sku_est < qtd_sku_mov:
                        qtd_sku_mov = qtd_sku_est
                        qtd_sku_est = qtd_sku_est - qtd_sku_mov
                    # Então reduz da variável de controle (qtde de estoque) a qtde movimentada
                    # Em seguida, adiciona no cursor de controle 'dat_aging'
                    aging = str(each_sku[0]), str(each_sku[1]), str(each_est[2]), str(each_sku[4]), \
                            str(qtd_sku_mov), str(each_sku[3]), str(qtd_sku_est)
                    dat_aging.append(aging)
                    # Somente podemos dar um commit na transação, quando o estoque do sku em um local
                    # chegar a zero. Esta transação é gravado na tabela resultado (DAT_).
                    if qtd_sku_est == 0:
                        for each_dat in dat_aging:
                            ins_res = 'INSERT INTO DAT_AGING (DATA_CALC_AGING, COD_LOCAL, COD_SKU, QTD_ESTOQUE, ' \
                                      'DATA_ENTRADA, QTD_RECEBIDA, ORIGEM_ENTRADA, SALDO) ' \
                                      'VALUES (CURDATE(), \'' + each_dat[0] + '\', \'' \
                                      + each_dat[1] + '\', \'' + each_dat[2] + '\', \'' + each_dat[3] + \
                                      '\', \'' + each_dat[4] + '\', \'' + each_dat[5] + '\', \'' \
                                      + each_dat[6] + '\');'
                            cur_tdv.execute(ins_res)
                            commit_db(con_tdv)
                        break
    except db_tdv.Error, tdv:
        rollback_db(con_tdv)
        # Registering the log
        log.grava_log_interface('Calculating AGING', 'Gravando os dados na TDV - Erro')
        errmsg = "ETL data target failed. Error %d: %s" % (tdv.args[0], tdv.args[1])
        status = 'NOK'
    except db_tdv.Warning:
        pass

    # Count rows after insert/update the table DAT_
    try:
        # Registering in the log
        log.grava_log_interface('Calculating AGING', 'Qtde. de linhas inseridas: ' + str(cur_tdv.rowcount))
    except db_tdv.Error, tdv:
        # Registering in the log
        log.grava_log_interface('Calculating AGING', 'Consultando o banco do cliente - Erro')
        errmsg = "ETL data source failed. Error %d: %s" % (tdv.args[0], tdv.args[1])
        status = 'NOK'
    except db_tdv.Warning:
        pass

    # Registering the log
    log.grava_log_interface('Calculating AGING', 'Fechando as conexoes com os bancos')

    # Registering the log
    log.grava_log_interface('Calculating AGING', 'Interface - termino')

    close_db(con_tdv)

    if status == 'OK':
        return status, 'Carga executada com sucesso!'
    else:
        return status, errmsg


if __name__ == '__main__':
    etl_dat_aging_loja()
