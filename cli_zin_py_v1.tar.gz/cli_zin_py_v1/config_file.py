#!/usr/bin/python
# -*- coding: utf-8 -*-


"""
Summary: CLI - database extract utility
Description: Generating a file with all the information to connect with the databases of the ZINZANE/TDVTEC
"""

# ===================================================================================================================
# VERSION:
# ===================================================================================================================
# 1.0 - 07/05/2016 - Laercio Serra - Generating a config file to be used in the others modules
# ===================================================================================================================

import os

# ===================================================================================================================
# PARAMETERS
# ===================================================================================================================
# Define the parameter to be saved in the config file
# host_db_from
# user_db_from
# pwd_db_from
# db_from
# host_db_to
# port_db_to
# user_db_to
# pwd_db_to
# db_to


# ===================================================================================================================
# Part 1 - Registering all the activities in the database of the TDVTEC
# ===================================================================================================================
path_file_cfg = os.getcwd()
os.chdir(path_file_cfg)

host_source = [('host_db_from', '200.218.248.69'),
               ('user_db_from', 'Leonardo'),
               ('pwd_db_from', 'Leo123456'),
               ('db_from', 'BDZINZANE')]
host_target = [('host_db_to', '75.126.143.46'),
               ('port_db_to', 30599),
               ('user_db_to', 'cli_zin_admin'),
               ('pwd_db_to', 'adminzinzane'),
               ('db_to', 'cli_zin')]


def save_to_file(host_source, host_target):
    """
    Save the parameters to the config files
    :param host_source:
    :param host_target:
    :return:
    """
    cfg_from = open('cfg_src.etl', 'w')
    cfg_to = open('cfg_tgt.etl', 'w')
    try:
        for value in host_source:
            cfg_from.write(str(value[0]) + ',' + str(value[1]) + '\n')

        for value in host_target:
            cfg_to.write(str(value[0]) + ',' + str(value[1]) + '\n')

    except ValueError:
        pass
    except IOError:
        print 'Erro no arquivo durante a gravação.'
    finally:
        cfg_from.close()
        cfg_to.close()


def load_from_file_host_source():
    """
    Read the config file and return the parameters of the host source
    :return:
    """
    cfg_source = []

    try:
        data = open('cfg_src.etl')

        for each_line in data:
            (parameter, value) = each_line.split(',')
            value = value.strip()
            cfg_source.append((parameter, value))

        return cfg_source
    except ValueError:
        pass
    except IOError:
        print 'O arquivo não foi encontrado.'
    finally:
        data.close()


def load_from_file_host_target():
    """
    Read the config file and return the parameters of the host target
    :return:
    """
    cfg_target = []

    try:
        data = open('cfg_tgt.etl')

        for each_line in data:
            (parameter, value) = each_line.split(',')
            value = value.strip()
            cfg_target.append((parameter, value))

        return cfg_target
    except ValueError:
        pass
    except IOError:
        print 'O arquivo não foi encontrado.'
    finally:
        data.close()

