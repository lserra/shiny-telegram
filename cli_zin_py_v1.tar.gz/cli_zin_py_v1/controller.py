#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
Summary: CLI - database extract utility
Description: Monitor and control all activities to move the data from ZINZANE server source to TDVTEC server target
"""

# ===================================================================================================================
# VERSION:
# ===================================================================================================================
# 1.0 - 07/05/2016 - Laercio Serra - This module do the monitoring and controlling of all activities to move the data
#                                    from ZINZANE server source to TDVTEC server target
# 2.0 - 14/06/2016 - Laercio Serra - Change the statement to extract the data from source RPL_HIERARQUIA_DE_PRODUTOS
# ===================================================================================================================
# TODO: 1- criar a classe de banco de dados
# TODO: 2- otimizar os inserts
# TODO: 3- refazer a rotina de logging
import smtplib
import sys

# List all process to be executed ETL_RPL_
import etl_rpl_locais as erl
import etl_rpl_fornec as erf
import etl_rpl_hiepro as erh
import etl_rpl_produt as erp
import etl_rpl_estoqu as ere
import etl_rpl_recebi as err
import etl_rpl_movint as erm
import etl_rpl_ajuinv as era
import etl_rpl_devcli as erd

# List all process to be executed ETL_BAS_
import etl_bas_locais as ebl
import etl_bas_fornec as ebf
import etl_bas_hiepro as ebh
import etl_bas_produt as ebp
import etl_bas_estoqu as ebe
import etl_bas_recebi as ebr
import etl_bas_movint as ebm
import etl_bas_ajuinv as eba
import etl_bas_devcli as ebd

# List all process to be executed ETL_AGR_
import etl_agr_movint as eam
import etl_calc_aging_loja as ecl
import etl_calc_aging_cia as ecc


# ===================================================================================================================
# Part 1 - Alerts by e-mail
# ===================================================================================================================
def send_message(step, status, msg):
    """
    Send an e-mail to the responsible (person) for the monitor/control these activities with the status and a
    description of the action/activity
    :param step:
    :param status:
    :param msg:
    :return:
    """
    try:
        smtp_server = 'smtp.webfaction.com'
        smtp_port = '587'
        user = 'tdvtec_automatico'
        fromaddr = 'pode_apagar@tdvtec.com.br'
        toaddr = 'laercio.serra@gmail.com; leonardo@tdvtec.com.br'
        subject = '[ZIN]-Carga ' + step + '-' + status
        header = 'To:' + toaddr + '\n' + 'From: ' + fromaddr + '\n' + \
                 'Subject:' + subject + '\n'

        body = 'Status: ' + status + '\r\n\n'
        body += msg + '\r\n\n'

        email = header + '\n' + body

        session = smtplib.SMTP(smtp_server, smtp_port)
        session.ehlo()
        session.starttls()
        session.ehlo()
        session.login(user, 'YFjpJklcPZfPmhcF')
        session.sendmail(fromaddr, toaddr, email)
        session.quit()
    except smtplib.SMTPException, smtp:
        error_msg = 'Failed to sending an e-mail. Error: %s' % smtp
        print error_msg


# ===================================================================================================================
# Part 2 - Monitor and Control
# ===================================================================================================================
def execute_etl_rpl():
    """
    Execute all the ETL processes (stage area/tables RPL_)
    """
    # Action 1
    source = 'LOCAIS'
    target = 'RPL_LOCAIS'
    print ">> Executando a Carga " + target + " ..."
    status, msg = erl.etl_from_to_rpl(source, target)
    send_message(target, status, msg)

    # Action 2
    source = 'FORNECEDOR'
    target = 'RPL_FORNECEDOR'
    print ">> Executando a Carga " + target + " ..."
    status, msg = erf.etl_from_to_rpl(source, target)
    send_message(target, status, msg)

    # Action 3
    # source = '[HIERARQUIA DE COD BARRAS]'
    target = 'RPL_HIERARQUIA_DE_PRODUTOS'
    print ">> Executando a Carga " + target + " ..."
    # status, msg = erh.etl_from_to_rpl(source, target)
    status, msg = erh.etl_from_to_rpl(target)
    send_message(target, status, msg)

    # Action 4
    source = 'PRODUTOS'
    target = 'RPL_PRODUTOS'
    print ">> Executando a Carga " + target + " ..."
    status, msg = erp.etl_from_to_rpl(source, target)
    send_message(target, status, msg)

    # Action 5
    source = 'ESTOQUE'
    target = 'RPL_ESTOQUE'
    print ">> Executando a Carga " + target + " ..."
    status, msg = ere.etl_from_to_rpl(source, target)
    send_message(target, status, msg)

    # Action 6
    source = 'RECEBIMENTO'
    target = 'RPL_RECEBIMENTO'
    print ">> Executando a Carga " + target + " ..."
    status, msg = err.etl_from_to_rpl(source, target)
    send_message(target, status, msg)

    # Action 7
    source = '[MOVIMENTACAO INTERNA]'
    target = 'RPL_MOVIMENTACAO_INTERNA'
    print ">> Executando a Carga " + target + " ..."
    status, msg = erm.etl_from_to_rpl(source, target)
    send_message(target, status, msg)

    # Action 8
    source = '[AJUSTE DE INVENTARIO]'
    target = 'RPL_AJUSTE_DE_INVENTARIO'
    print ">> Executando a Carga " + target + " ..."
    status, msg = era.etl_from_to_rpl(source, target)
    send_message(target, status, msg)

    # Action 9
    source = '[DEVOLUCAO DE CLIENTES]'
    target = 'RPL_DEVOLUCAO_DE_CLIENTES'
    print ">> Executando a Carga " + target + " ..."
    status, msg = erd.etl_from_to_rpl(source, target)
    send_message(target, status, msg)


def execute_etl_bas():
    """
    Execute all the ETL processes (data mart/tables BAS_)
    """
    # Action 1
    source = 'RPL_LOCAIS'
    target = 'BAS_LOCAL'
    print ">> Executando a Carga " + target + " ..."
    status, msg = ebl.etl_from_to_bas(source, target)
    send_message(target, status, msg)

    # Action 2
    source = 'RPL_FORNECEDOR'
    target = 'BAS_FORNECEDOR'
    print ">> Executando a Carga " + target + " ..."
    status, msg = ebf.etl_from_to_bas(source, target)
    send_message(target, status, msg)

    # Action 3
    source = 'RPL_HIERARQUIA_DE_PRODUTOS'
    target = 'BAS_HIERARQUIA_DE_PRODUTO'
    print ">> Executando a Carga " + target + " ..."
    status, msg = ebh.etl_from_to_bas(source, target)
    send_message(target, status, msg)

    # Action 4
    source = 'RPL_PRODUTOS'
    target = 'BAS_PRODUTO'
    print ">> Executando a Carga " + target + " ..."
    status, msg = ebp.etl_from_to_bas(source, target)
    send_message(target, status, msg)

    # Action 5
    source = 'RPL_ESTOQUE'
    target = 'BAS_ESTOQUE'
    print ">> Executando a Carga " + target + " ..."
    status, msg = ebe.etl_from_to_bas(source, target)
    send_message(target, status, msg)

    # Action 6
    # source = 'RPL_RECEBIMENTO'
    target = 'BAS_RECEBIMENTO'
    print ">> Executando a Carga " + target + " ..."
    status, msg = ebr.etl_from_to_bas(target)
    send_message(target, status, msg)

    # Action 7
    # source = 'RPL_MOVIMENTACAO_INTERNA'
    target = 'BAS_MOVIMENTACAO_INTERNA'
    print ">> Executando a Carga " + target + " ..."
    status, msg = ebm.etl_from_to_bas(target)
    send_message(target, status, msg)

    # Action 8
    # source = 'RPL_AJUSTE_DE_INVENTARIO'
    target = 'BAS_AJUSTE_DE_INVENTARIO'
    print ">> Executando a Carga " + target + " ..."
    status, msg = eba.etl_from_to_bas(target)
    send_message(target, status, msg)

    # Action 9
    # source = 'RPL_DEVOLUCAO_DE_CLIENTES'
    target = 'BAS_DEVOLUCAO_DE_CLIENTE'
    print ">> Executando a Carga " + target + " ..."
    status, msg = ebd.etl_from_to_bas(target)
    send_message(target, status, msg)


def execute_calc_aging():
    """
    Execute all the ETL processes (AGR_/DAT_) to calculate aging
    """
    # Action 1
    target = 'AGR_MOVIMENTACAO'
    print ">> Executando a Carga " + target + " ..."
    status, msg = eam.etl_agr_movint(target)
    send_message(target, status, msg)

    # Action 2
    target = 'DAT_AGING_LOJA'
    print ">> Executando a Carga " + target + " ..."
    status, msg = ecl.etl_dat_aging_loja(target)
    send_message(target, status, msg)

    # Action 3
    target = 'DAT_AGING_CIA'
    print ">> Executando a Carga " + target + " ..."
    status, msg = ecc.etl_dat_aging_cia(target)
    send_message(target, status, msg)


def monitor_and_control_app():
    """
    Monitor and control all the activities of ETL and movement of the data from ZINZANE to TDVTEC
    """
    # Execute all the ETL processes (stage area/tables RPL_)
    execute_etl_rpl()
    # Execute all the ETL processes (data mart/tables BAS_)
    execute_etl_bas()
    # Execute all the ETL processes (data mart/tables AGR_, DAT_)
    execute_calc_aging()
    # Send a message to system administrator and close the application
    print ">> Fim do processamento."

    sys.exit(0)


if __name__ == '__main__':
    monitor_and_control_app()
