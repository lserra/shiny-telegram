#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
Summary: CLI - database extract utility
Description: Execute just one job/ETL process
"""

# ===================================================================================================================
# VERSION:
# ===================================================================================================================
# 1.0 - 20/05/2016 - Laercio Serra - This module can executing just one job/ETL process
# ===================================================================================================================

import smtplib
# import log_function as log
import etl_calc_aging_loja as ecl
import etl_calc_aging_cia as ecc
import sys


# ===================================================================================================================
# Part 1 - Alerts by e-mail
# ===================================================================================================================
def send_message(step, status, msg):
    """
    Send an e-mail to the responsible (person) for the monitor/control these activities with the status and a
    description of the action/activity
    :param step:
    :param status:
    :param msg:
    :return:
    """
    try:
        smtp_server = 'smtp.webfaction.com'
        smtp_port = '587'
        user = 'tdvtec_automatico'
        fromaddr = 'pode_apagar@tdvtec.com.br'
        toaddr = 'laercio.serra@gmail.com; leonardo@tdvtec.com.br'
        # toaddr = 'laercio.serra@gmail.com'
        subject = '[ZIN]-Carga ' + step + '-' + status
        header = 'To:' + toaddr + '\n' + 'From: ' + fromaddr + '\n' + \
                 'Subject:' + subject + '\n'

        body = 'Status: ' + status + '\r\n\n'
        body += msg + '\r\n\n'

        email = header + '\n' + body

        session = smtplib.SMTP(smtp_server, smtp_port)
        session.ehlo()
        session.starttls()
        session.ehlo()
        session.login(user, 'YFjpJklcPZfPmhcF')
        session.sendmail(fromaddr, toaddr, email)
        session.quit()

        # return True, 'Email enviado com sucesso - termino'

    except smtplib.SMTPException, smtp:
        error_msg = 'Failed to sending an e-mail. Error: %s' % smtp
        print error_msg
        # return False, error_msg


# ===================================================================================================================
# Part 2 - Executing the job/ETL process
# ===================================================================================================================
if __name__ == '__main__':
    # Job/ETL process
    target = 'DAT_AGING_LOJA'
    print ">> Executando a Carga " + target + " ..."
    status, msg = ecl.etl_dat_aging_loja(target)
    send_message(target, status, msg)

    target = 'DAT_AGING_CIA'
    print ">> Executando a Carga " + target + " ..."
    status, msg = ecc.etl_dat_aging_cia(target)
    send_message(target, status, msg)

    # Send a message to system administrator and close the application
    print ">> Fim do processamento."
    sys.exit(0)
